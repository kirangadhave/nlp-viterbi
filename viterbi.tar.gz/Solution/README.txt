a)  Programming language used: Python
    Version: Python3.6

b)  Instructions for running:
    1. cd into the ngrams directory.

    2. Type - "python3.6 viterbi <probabilities_file> <sentence_files>"

c) Tested on cade machine #lab1-1

d) Limitations, bugs or problems - None as per my tests
